extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0

#double jump 
var jump_count = 0
var max_jump = 1

#swipe 
var swipe_start = Vector2.ZERO
var swipe_threshold = 200
const move_amont = 100

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			swipe_start = event.position
		else:
			var swipe_end = event.position
			var swipe_vector = swipe_end - swipe_start
			
			if swipe_vector.length() > swipe_threshold:
				if abs(swipe_vector.x) > abs(swipe_vector.y):
					if swipe_vector.x > 0:
						move_right()
					else:
						move_left()
				else:
					if swipe_vector.y <0:
						swipe_jump()
					elif swipe_vector.y >0:
						swipe_fall()
						
						
func swipe_jump():
	if is_on_floor() or jump_count<max_jump:
		velocity.y = JUMP_VELOCITY
		jump_count += 1
		
func swipe_fall():
	if !is_on_floor():
		velocity.y += 300
func move_right():
	velocity.x += lerp(velocity.x ,SPEED,5.0)
func move_left():
	velocity.x -= lerp(velocity.x ,SPEED,5.0)
#respawner player 
var respawner = Vector2(250,340)

func _physics_process(delta: float) -> void:
	
	#dead player and respawner
	if position.y >500:
		position = respawner
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and (is_on_floor() or jump_count <max_jump ):
		velocity.y = JUMP_VELOCITY
		jump_count += 1
		
	#double jump
	if is_on_floor():
		jump_count = 0

	# Input direction (
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")

	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
