@tool
extends EditorPlugin



var save_timer: Timer

func _enter_tree():
	
	
	save_timer = Timer.new()

	save_timer.wait_time = 60  # الحفظ كل 60 ثانية
	save_timer.autostart = true
	save_timer.one_shot = false
	save_timer.timeout.connect(_auto_save)
	add_child(save_timer)

func _auto_save():
	var editor = get_editor_interface()
	editor.save_all_scenes()  # حفظ جميع المشاهد المفتوحة
	editor.get_resource_filesystem().scan()  # تحديث الملفات
	
func _exit_tree():
	
	if save_timer:
		
		save_timer.queue_free() 
		
		
		
